"""
Device Manager
==============

Gestiona la selección dinámica de GPUs y discos NVMe disponibles.
"""

import torch
import os
import subprocess
import logging
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class GPUInfo:
    """Información de una GPU"""
    device_id: int
    name: str
    total_memory: float  # GB
    available_memory: float  # GB
    compute_capability: Tuple[int, int]
    
    def __str__(self) -> str:
        return f"GPU {self.device_id}: {self.name} ({self.available_memory:.1f}GB/{self.total_memory:.1f}GB)"


@dataclass
class NVMeInfo:
    """Información de un disco NVMe"""
    device_path: str
    mount_point: str
    total_size: float  # GB
    available_size: float  # GB
    
    def __str__(self) -> str:
        return f"NVMe {self.device_path}: {self.available_size:.1f}GB/{self.total_size:.1f}GB"


class DeviceManager:
    """Gestor de dispositivos disponibles"""
    
    def __init__(self):
        self.gpus: List[GPUInfo] = []
        self.nvmes: List[NVMeInfo] = []
        self.selected_gpu: Optional[int] = None
        self.selected_nvme: Optional[str] = None
        
        # Detectar dispositivos
        self._detect_gpus()
        self._detect_nvmes()
    
    def _detect_gpus(self):
        """Detecta GPUs disponibles"""
        if not torch.cuda.is_available():
            logger.warning("CUDA no disponible")
            return
        
        num_gpus = torch.cuda.device_count()
        logger.info(f"Detectadas {num_gpus} GPUs")
        
        for device_id in range(num_gpus):
            props = torch.cuda.get_device_properties(device_id)
            
            # Obtener memoria
            total_memory = props.total_memory / (1024**3)  # GB
            allocated = torch.cuda.memory_allocated(device_id) / (1024**3)
            available = total_memory - allocated
            
            gpu_info = GPUInfo(
                device_id=device_id,
                name=props.name,
                total_memory=total_memory,
                available_memory=available,
                compute_capability=(props.major, props.minor)
            )
            
            self.gpus.append(gpu_info)
            logger.info(f"GPU {device_id}: {gpu_info}")
    
    def _detect_nvmes(self):
        """Detecta discos NVMe disponibles"""
        try:
            # Buscar discos NVMe
            result = subprocess.run(
                ["lsblk", "-d", "-n", "-o", "NAME,SIZE,MOUNTPOINT"],
                capture_output=True,
                text=True,
                timeout=5
            )
            
            for line in result.stdout.strip().split('\n'):
                if 'nvme' in line:
                    parts = line.split()
                    if len(parts) >= 2:
                        device = parts[0]
                        device_path = f"/dev/{device}"
                        
                        # Obtener tamaño
                        try:
                            size_result = subprocess.run(
                                ["blockdev", "--getsize64", device_path],
                                capture_output=True,
                                text=True,
                                timeout=5
                            )
                            total_size = int(size_result.stdout.strip()) / (1024**3)  # GB
                            
                            # Obtener punto de montaje
                            mount_result = subprocess.run(
                                ["findmnt", "-n", "-o", "TARGET", device_path],
                                capture_output=True,
                                text=True,
                                timeout=5
                            )
                            mount_point = mount_result.stdout.strip() or "No montado"
                            
                            # Obtener espacio disponible
                            if mount_point != "No montado" and os.path.exists(mount_point):
                                stat = os.statvfs(mount_point)
                                available_size = (stat.f_bavail * stat.f_frsize) / (1024**3)
                            else:
                                available_size = 0
                            
                            nvme_info = NVMeInfo(
                                device_path=device_path,
                                mount_point=mount_point,
                                total_size=total_size,
                                available_size=available_size
                            )
                            
                            self.nvmes.append(nvme_info)
                            logger.info(f"NVMe: {nvme_info}")
                        
                        except Exception as e:
                            logger.warning(f"Error detectando NVMe {device_path}: {e}")
        
        except Exception as e:
            logger.warning(f"Error detectando NVMes: {e}")
    
    def get_available_gpus(self) -> List[GPUInfo]:
        """Retorna lista de GPUs disponibles"""
        return self.gpus
    
    def get_available_nvmes(self) -> List[NVMeInfo]:
        """Retorna lista de NVMes disponibles"""
        return self.nvmes
    
    def select_gpu(self, device_id: int) -> bool:
        """Selecciona una GPU"""
        if device_id < 0 or device_id >= len(self.gpus):
            logger.error(f"GPU {device_id} no válida")
            return False
        
        self.selected_gpu = device_id
        torch.cuda.set_device(device_id)
        logger.info(f"GPU seleccionada: {device_id}")
        return True
    
    def select_nvme(self, mount_point: str) -> bool:
        """Selecciona un NVMe"""
        for nvme in self.nvmes:
            if nvme.mount_point == mount_point:
                self.selected_nvme = mount_point
                logger.info(f"NVMe seleccionado: {mount_point}")
                return True
        
        logger.error(f"NVMe {mount_point} no encontrado")
        return False
    
    def get_selected_device(self) -> Dict:
        """Retorna información del dispositivo seleccionado"""
        return {
            "gpu": self.selected_gpu,
            "nvme": self.selected_nvme,
            "gpu_info": self.gpus[self.selected_gpu] if self.selected_gpu is not None else None,
            "nvme_info": next(
                (n for n in self.nvmes if n.mount_point == self.selected_nvme),
                None
            ) if self.selected_nvme else None
        }
    
    def get_device_status(self) -> Dict:
        """Retorna estado completo de dispositivos"""
        return {
            "gpus": [
                {
                    "id": gpu.device_id,
                    "name": gpu.name,
                    "total_memory_gb": gpu.total_memory,
                    "available_memory_gb": gpu.available_memory,
                    "compute_capability": f"{gpu.compute_capability[0]}.{gpu.compute_capability[1]}"
                }
                for gpu in self.gpus
            ],
            "nvmes": [
                {
                    "device": nvme.device_path,
                    "mount_point": nvme.mount_point,
                    "total_size_gb": nvme.total_size,
                    "available_size_gb": nvme.available_size
                }
                for nvme in self.nvmes
            ],
            "selected": self.get_selected_device()
        }
    
    def get_torch_device(self) -> torch.device:
        """Retorna torch.device para el GPU seleccionado"""
        if self.selected_gpu is not None and torch.cuda.is_available():
            return torch.device(f"cuda:{self.selected_gpu}")
        return torch.device("cpu")


# Ejemplo de uso
if __name__ == "__main__":
    print("=" * 70)
    print("DEVICE MANAGER - EJEMPLO")
    print("=" * 70)
    
    # Crear manager
    manager = DeviceManager()
    
    # Ver dispositivos disponibles
    print("\n📊 Dispositivos Disponibles:")
    print("\nGPUs:")
    for gpu in manager.get_available_gpus():
        print(f"  {gpu}")
    
    print("\nNVMes:")
    for nvme in manager.get_available_nvmes():
        print(f"  {nvme}")
    
    # Seleccionar dispositivos
    if manager.get_available_gpus():
        manager.select_gpu(0)
    
    if manager.get_available_nvmes():
        manager.select_nvme(manager.get_available_nvmes()[0].mount_point)
    
    # Ver estado
    print("\n✅ Estado del Sistema:")
    import json
    print(json.dumps(manager.get_device_status(), indent=2, default=str))
