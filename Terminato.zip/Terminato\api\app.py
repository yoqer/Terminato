"""
Terminato Web API
=================

API REST para control del framework Terminato.
"""

from fastapi import FastAPI, HTTPException, UploadFile, File, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List, Dict, Optional, Any
import logging
import torch
import os
from pathlib import Path

# Importar componentes de Terminato
import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.device_manager import DeviceManager
from training.trainer import TrainingManager

logger = logging.getLogger(__name__)

# Crear app
app = FastAPI(
    title="Terminato API",
    version="1.0.0",
    description="API para control de entrenamientos con TeMiNaTor"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Estado global
class AppState:
    def __init__(self):
        self.device_manager = DeviceManager()
        self.training_manager = None
        self.initialized = False

state = AppState()


# Modelos Pydantic
class DeviceSelection(BaseModel):
    gpu_id: Optional[int] = None
    nvme_mount: Optional[str] = None


class TrainingConfig(BaseModel):
    session_name: str
    model_path: str
    dataset_path: str
    learning_rate: float = 0.001
    batch_size: int = 32
    max_epochs: int = 100
    frozen_layers: List[str] = []


class ModelFusionRequest(BaseModel):
    session_id: str
    model_paths: List[str]
    strategy: str = "average"


class LayerAnalysisRequest(BaseModel):
    session_id: str
    layer_name: str


# Endpoints

@app.on_event("startup")
async def startup():
    """Inicializa la aplicación"""
    logger.info("Iniciando Terminato API...")
    
    # Seleccionar GPU por defecto
    gpus = state.device_manager.get_available_gpus()
    if gpus:
        state.device_manager.select_gpu(0)
    
    # Seleccionar NVMe por defecto
    nvmes = state.device_manager.get_available_nvmes()
    if nvmes:
        state.device_manager.select_nvme(nvmes[0].mount_point)
    
    # Crear training manager
    device = state.device_manager.get_torch_device()
    nvme_path = state.device_manager.selected_nvme
    state.training_manager = TrainingManager(device, nvme_path)
    
    state.initialized = True
    logger.info("Terminato API iniciada")


@app.get("/")
async def root():
    """Endpoint raíz"""
    return {
        "name": "Terminato API",
        "version": "1.0.0",
        "status": "running" if state.initialized else "initializing"
    }


@app.get("/health")
async def health_check():
    """Verifica el estado del sistema"""
    return {
        "status": "healthy" if state.initialized else "initializing",
        "gpu_available": torch.cuda.is_available(),
        "device_count": torch.cuda.device_count() if torch.cuda.is_available() else 0
    }


@app.get("/api/devices")
async def get_devices():
    """Obtiene información de dispositivos disponibles"""
    return state.device_manager.get_device_status()


@app.post("/api/devices/select")
async def select_devices(selection: DeviceSelection):
    """Selecciona GPU y/o NVMe"""
    try:
        if selection.gpu_id is not None:
            if not state.device_manager.select_gpu(selection.gpu_id):
                raise HTTPException(status_code=400, detail="GPU no válida")
        
        if selection.nvme_mount is not None:
            if not state.device_manager.select_nvme(selection.nvme_mount):
                raise HTTPException(status_code=400, detail="NVMe no válido")
        
        # Recrear training manager con nuevos dispositivos
        device = state.device_manager.get_torch_device()
        nvme_path = state.device_manager.selected_nvme
        state.training_manager = TrainingManager(device, nvme_path)
        
        return {
            "success": True,
            "selected": state.device_manager.get_selected_device()
        }
    
    except Exception as e:
        logger.error(f"Error seleccionando dispositivos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/training/create")
async def create_training_session(config: TrainingConfig):
    """Crea una nueva sesión de entrenamiento"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        session_id = state.training_manager.create_training_session(
            session_name=config.session_name,
            model_path=config.model_path,
            dataset_path=config.dataset_path,
            config={
                "learning_rate": config.learning_rate,
                "batch_size": config.batch_size,
                "max_epochs": config.max_epochs
            }
        )
        
        # Congelar capas si se especifican
        if config.frozen_layers:
            state.training_manager.freeze_layers(session_id, config.frozen_layers)
        
        return {
            "session_id": session_id,
            "status": "created"
        }
    
    except Exception as e:
        logger.error(f"Error creando sesión: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/training/start")
async def start_training(session_id: str, background_tasks: BackgroundTasks):
    """Inicia el entrenamiento de una sesión"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        session = state.training_manager.get_session_status(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Sesión no encontrada")
        
        config = session.get("training_config", {})
        
        # Ejecutar entrenamiento en background
        background_tasks.add_task(
            state.training_manager.start_training,
            session_id,
            config.get("learning_rate", 0.001),
            config.get("batch_size", 32),
            config.get("max_epochs", 100)
        )
        
        return {
            "session_id": session_id,
            "status": "training_started"
        }
    
    except Exception as e:
        logger.error(f"Error iniciando entrenamiento: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/training/status/{session_id}")
async def get_training_status(session_id: str):
    """Obtiene el estado de una sesión de entrenamiento"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        status = state.training_manager.get_session_status(session_id)
        if not status:
            raise HTTPException(status_code=404, detail="Sesión no encontrada")
        
        return status
    
    except Exception as e:
        logger.error(f"Error obteniendo estado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/models/fuse")
async def fuse_models(request: ModelFusionRequest):
    """Fusiona múltiples modelos"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        success = state.training_manager.fuse_models(
            request.session_id,
            request.model_paths,
            request.strategy
        )
        
        if not success:
            raise HTTPException(status_code=500, detail="Error fusionando modelos")
        
        return {
            "session_id": request.session_id,
            "status": "models_fused",
            "strategy": request.strategy
        }
    
    except Exception as e:
        logger.error(f"Error fusionando modelos: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/layers/analyze")
async def analyze_layer(request: LayerAnalysisRequest):
    """Analiza una capa específica"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        analysis = state.training_manager.evaluate_layer(
            request.session_id,
            request.layer_name
        )
        
        if not analysis:
            raise HTTPException(status_code=500, detail="Error analizando capa")
        
        return analysis
    
    except Exception as e:
        logger.error(f"Error analizando capa: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/training/sessions")
async def list_training_sessions():
    """Lista todas las sesiones de entrenamiento"""
    try:
        if not state.training_manager:
            raise HTTPException(status_code=503, detail="Training manager no disponible")
        
        sessions = state.training_manager.get_all_sessions()
        
        return {
            "sessions": sessions,
            "count": len(sessions)
        }
    
    except Exception as e:
        logger.error(f"Error listando sesiones: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Ejecutar servidor
if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
